package com.example.pertemuan5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Menu4 extends AppCompatActivity {

    EditText Text_Nama;
    TextView Hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu4);

        //Memanggil berdasar id objek
        Text_Nama = findViewById(R.id.Txt_Nama);
        Hasil = findViewById(R.id.Lbl_Hasil);
    }

    public void Tampil_Hasil(View v){
        Hasil.setText("Nama Anda Adalah :" + Text_Nama.getText());
    }
}
