package com.example.pertemuan5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Scanner;

public class MenuAkar extends AppCompatActivity {

    EditText Text_Angka;
    TextView Hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_akar);

        Text_Angka = findViewById(R.id.Txt_Angka);
        Hasil = findViewById(R.id.Lbl_Hasil);
    }

    public void Tampil_Hasil(View v){
        int x, y;
        String angka = Text_Angka.getText().toString();
        int akar = Integer.parseInt(angka);

        x = 1;
        y = x * x;

        while (y != akar){
            x = x + 1;
            y = x * x;

        }
        Hasil.setText("Akarnya Adalah : " + x);
    }
}
