package com.example.pertemuan5;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.V;

public class Menu1 extends AppCompatActivity {
    // Deklarasi Button java
    Button BtnOk1, BtnOk2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

        // Menghubngkan
        BtnOk1 = findViewById(R.id.Btn1);
        BtnOk2 = findViewById(R.id.Btn2);
    }
    public void Rubah_Warna(View v)
    {
        BtnOk1.setBackgroundColor(Color.RED);
    }
    public void Rubah_Warna2(View v)
    {
        BtnOk2.setBackgroundColor(Color.GREEN);
    }
}